package edu.miu.cs.cs425.eregistrar.Service;

import edu.miu.cs.cs425.eregistrar.model.Course;

public interface CourseService {
    public Course saveCourse(Course course);
}
