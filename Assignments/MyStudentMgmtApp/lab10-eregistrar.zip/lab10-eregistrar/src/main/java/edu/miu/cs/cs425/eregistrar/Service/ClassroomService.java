package edu.miu.cs.cs425.eregistrar.Service;

import edu.miu.cs.cs425.eregistrar.model.Classroom;

public interface ClassroomService {
    public Classroom saveClassroom(Classroom classroom);
}
