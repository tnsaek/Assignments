package edu.miu.cs.cs425.eregistrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab10EregistrarApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab10EregistrarApplication.class, args);
    }

}
