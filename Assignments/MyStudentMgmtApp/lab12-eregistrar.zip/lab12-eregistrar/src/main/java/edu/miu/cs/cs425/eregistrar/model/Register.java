package edu.miu.cs.cs425.eregistrar.model;

import lombok.Data;

@Data
public class Register {
    private String username;
    private String password;
}
