package edu.miu.cs.cs425.eregistrar.Service;

import edu.miu.cs.cs425.eregistrar.model.Transcript;

public interface TranscriptService {
    public Transcript saveTranscript(Transcript transcript);
}
