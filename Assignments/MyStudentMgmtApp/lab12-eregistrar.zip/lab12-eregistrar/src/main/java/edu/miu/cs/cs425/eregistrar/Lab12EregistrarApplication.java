package edu.miu.cs.cs425.eregistrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab12EregistrarApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab12EregistrarApplication.class, args);
    }

}
