package edu.miu.cs.cs425.eregistrar.Service;

import edu.miu.cs.cs425.eregistrar.model.Role;

import java.util.List;

public interface RoleService {
    public abstract List<Role> getAllRoles();
}
